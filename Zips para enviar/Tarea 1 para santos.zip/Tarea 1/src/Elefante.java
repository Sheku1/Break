import java.awt.Image;

//metodo constructor que hereda de la clase animal los atributos, pos x es posicion x del elefante.
//imagen es la imagen del elefante..
public class Elefante extends Animal{
    public Elefante(int posX,int posY,Image image){
		super(posX,posY,image);	
	}  
}